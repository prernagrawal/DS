package com.company.financialadvisorsupportsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialadvisorsupportsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
